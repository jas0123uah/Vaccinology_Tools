#define	kLength     11000 
#define	kMaxSeqLen	11000  // must be <= kLength
#define	kMaxSeqName  300	 
#define	kAtoOne      64	 
#define	kMinProb      0  // which connections to compute
#define	kStates      64  
#define	kdefCutoff   0.005  
#define	kperiodStdout1  5  
#define	kperiodStdout2  200  
#define	kperiodStdout3  1000  
#define	kParsingthreshold1  0.02  
#define	kParsingthreshold2  0.10  
#define	kParsingthreshold3  0.50  
#define	kParsingthreshold4  0.90  
#define	kParsingthreshold5  0.99  






